﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto1
{
    internal class IP : Calculo
    {
        public float Ventas { get; set; }
        public float RecursoUtilizado { get; set; }
        
        public IP(float ventas, float recursoUtilizado)
        {
            Ventas = ventas;
            RecursoUtilizado = recursoUtilizado;
        }

        public override void CalculoTotal()
        {
            Calcular = Ventas / RecursoUtilizado;
        }

    }
}
