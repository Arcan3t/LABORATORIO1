﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto1
{
    internal class IPMO : Calculo
    {
        public float PVU { get; set; }
        public float NP { get; set; }
        public float CHMO { get; set; }
        public float NHE { get; set; }
        public IPMO(float pVU, float nP, float cHMO, float nHE)
        {
            PVU = pVU;
            NP = nP;
            CHMO = cHMO;
            NHE = nHE;
        }

        public override void CalculoTotal()
        {
            Calcular = (PVU * NP)/(CHMO * NHE);
        }

    }
}
