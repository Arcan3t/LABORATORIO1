﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto1
{
    internal class IPMP : Calculo
    {
        public float CTMP { get; set; }
        public float PVU { get; set; }
        public float NP { get; set; }
        public IPMP(float cTMP, float pVU, float nP)
        {
            CTMP = cTMP;
            PVU = pVU;
            NP = nP;
        }

        public override void CalculoTotal()
        {
            Calcular = (PVU * NP) / CTMP;
        }
    }
}
