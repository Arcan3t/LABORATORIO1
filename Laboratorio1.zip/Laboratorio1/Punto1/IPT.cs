﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto1
{
    internal class IPT : Calculo
    {
        public float Depreciacion { get; set; }
        public float Gastos { get; set; }
        public float CTMP { get; set; }
        public float PVU { get; set; }
        public float NP { get; set; }
        public float CMO { get; set; }
        public IPT(float depreciacion, float gastos, float cTMP, float pVU, float nP, float cMO)
        {
            Depreciacion = depreciacion;
            Gastos = gastos;
            CTMP = cTMP;
            PVU = pVU;
            NP = nP;
            CMO = cMO;
        }
        public override void CalculoTotal()
        {
            Calcular = ((PVU * NP) / (CMO + CTMP + Depreciacion + Gastos));
        }
    }
}
