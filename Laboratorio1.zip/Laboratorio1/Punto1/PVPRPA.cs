﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto1
{
    internal class PVPRPA : Calculo
    {
        public float IPTP1 { get; set; }
        public float IPTP2 { get; set; }
        public PVPRPA(float iPTP1, float iPTP2)
        {
            IPTP1 = iPTP1;
            IPTP2 = iPTP2;
        }

        public override void CalculoTotal()
        {
            Calcular = ((IPTP1 - (IPTP2 - 1)) / (IPTP2 - 1) );
        }
    }
}
