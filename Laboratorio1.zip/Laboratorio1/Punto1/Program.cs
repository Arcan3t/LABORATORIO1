﻿namespace Punto1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            float ventas = 0;           //VENTAS
            float recursoutilizado = 0; //RECURSO UTILIZADO
            float depreciacion = 0;     //DEPRESIACION
            float gastos = 0;           //GASTOS
            float pVU = 0;              //PRECIO DE VENTA UNITARIO
            float nP = 0;               //NIVEL DE PRODUCCIÓN
            float cHMO = 0;             //COSTO HORA DE MANO DE OBRA
            float nHE = 0;              //NUMERO DE HORAS EMPLEADAS
            float cTMP = 0;             //COSTO TOTAL DE MATERIA PRIMA
            float cMO = 0;              //COSTO DE MANO DE OBRA
            float iPTP1 = 0;            //INDICE DE PRODUCTIVIDAD DEL PRIMER PERIODO
            float iPTP2 = 0;            //INDICE DE PRODUCTIVIDAD DEL SEGUNDO PERIODO

            Console.WriteLine("HOLA MUNDO");
            Console.WriteLine("BIENVENIDOS A MI TRABAJO - LABORATORIO - PUNTO 1");

            //INIDICE DE PRODUCTIVIDAD
            Console.WriteLine("\n*** INDICE DE PRODUCTIVIDAD ***");
            Console.WriteLine("Total de Ventas              : ");
            ventas = float.Parse(Console.ReadLine());
            Console.WriteLine("Total de Recurso Utilizado   : ");
            recursoutilizado = float.Parse(Console.ReadLine());

            IP Calculo1 = new IP(ventas, recursoutilizado);
            Calculo1.CalculoTotal();
            Console.WriteLine("EL INDICE DE PRODUCTIVIDAD ES    : " + Calculo1.Calcular);

            //INDICE DE PRODUCTIVIDAD DE MANO DE OBRA
            Console.WriteLine("\n*** INDICE DE PRODUCTIVIDAD DE MANO DE OBRA ***");
            Console.WriteLine("Precio de Venta Unitario     : ");
            pVU = float.Parse(Console.ReadLine());
            Console.WriteLine("Nivel de Producción          : ");
            nP = float.Parse(Console.ReadLine());
            Console.WriteLine("Costo Hora de Mano de Obra   : ");
            cHMO = float.Parse(Console.ReadLine());
            Console.WriteLine("# de Horas Empleadas         : ");
            nHE = float.Parse(Console.ReadLine());

            IPMO Calculo2 = new IPMO(pVU, nP, cHMO, nHE);
            Calculo2.CalculoTotal();
            Console.WriteLine("EL INDICE DE PRODUCTIVIDAD DE MANO DE OBRA ES    : " + Calculo2.Calcular);

            //INDICE DE PRODUCTIVIDAD DE MATERIA PRIMA
            Console.WriteLine("\n*** INDICE DE PRODUCTIVIDAD DE MATERIA PRIMA ***");
            Console.WriteLine("Precio de Venta Unitario     : ");
            pVU = float.Parse(Console.ReadLine());
            Console.WriteLine("Nivel de Producción          : ");
            nP = float.Parse(Console.ReadLine());
            Console.WriteLine("Costo Total de Materia Prima : ");
            cTMP = float.Parse(Console.ReadLine());
            
            IPMP Calculo3 = new IPMP(cTMP, pVU, nP);
            Calculo3.CalculoTotal();
            Console.WriteLine("EL INDICE DE PRODUCTIVIDAD DE MATERIA PRIMA ES   : " + Calculo3.Calcular);

            //INDICE DE PRODUCTIVIDAD TOTAL
            Console.WriteLine("\n*** INDICE DE PRODUCTIVIDAD TOTAL ***");
            Console.WriteLine("Precio de Venta Unitario     : ");
            pVU = float.Parse(Console.ReadLine());
            Console.WriteLine("Nivel de Producción          : ");
            nP = float.Parse(Console.ReadLine());
            Console.WriteLine("Costos de Mano de Obra       : ");
            cMO = float.Parse(Console.ReadLine());
            Console.WriteLine("Costo Total de Materia Prima : ");
            cTMP = float.Parse(Console.ReadLine());
            Console.WriteLine("Depreciacion                 : ");
            depreciacion = float.Parse(Console.ReadLine());
            Console.WriteLine("Gastos                       : ");
            gastos = float.Parse(Console.ReadLine());

            IPT Calculo4 = new IPT(depreciacion, gastos, cTMP, pVU, nP, cMO);
            Calculo4.CalculoTotal();
            Console.WriteLine("EL INDICE DE PRODUCTIVIDAD TOTAL ES   : " + Calculo4.Calcular);

            //INIDICE DE PRODUCTIVIDAD
            Console.WriteLine("\n*** % VARIACIÓN DE LA PRODUCTIVIDAD RESPECTO AL PERIODO ANTERIOR ***");
            Console.WriteLine("IPT del Periodo 1            : ");
            iPTP1 = float.Parse(Console.ReadLine());
            Console.WriteLine("IPT del Periodo Base         : ");
            iPTP2 = float.Parse(Console.ReadLine());

            PVPRPA Calculo5 = new PVPRPA(iPTP1, iPTP2);
            Calculo5.CalculoTotal();
            Console.WriteLine("LA VARIACIÓN ES DEL    : " + Calculo5.Calcular + "%");
        }
    }
}