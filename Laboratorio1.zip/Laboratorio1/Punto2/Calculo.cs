﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto2
{
    internal abstract class Calculo
    {
        public float Calcular { get; set; }
        abstract public void CalculoTotal();
    }
}
