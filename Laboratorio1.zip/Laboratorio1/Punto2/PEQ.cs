﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto2
{
    internal class PEQ : Calculo
    {
        public float PV { get; set; }
        public float CVU { get; set; }
        public float MCU { get; set; }
        public float CF { get; set; }
        public float PEQU { get; set; }
        public float PEQM { get; set; }
        public PEQ(float pV, float cVU, float cF)
        {
            PV = pV;
            CVU = cVU;
            CF = cF;
            PEQU = 0;
            PEQM = 0;
            MCU = 0;
        }

        public override void CalculoTotal()
        {
            MCU = PV - CVU;
            PEQU = CF / MCU;
            PEQM = CF / (1 - (CVU / PV));
        }




    }
}
