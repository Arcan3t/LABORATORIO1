﻿namespace Punto2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            float pV = 0;   //PRECIO DE VENTA UNITARIO
            float cVU = 0;  //COSTO VARIABLE UNITARIO
            float cF = 0;   //COSTOS FIJOS TOTALES

            Console.WriteLine("HOLA MUNDO");
            Console.WriteLine("BIENVENIDOS A MI TRABAJO - LABORATORIO - PUNTO 2");

            Console.WriteLine("\n*** CALCULO DEL PUNTO DE EQUILIBRIO ***");
            Console.WriteLine("Precio de Venta Unitario (P.V.)       : ");
            pV = float.Parse(Console.ReadLine());
            Console.WriteLine("Costo Variable Unitario (C.V.U.)      : ");
            cVU = float.Parse(Console.ReadLine());
            Console.WriteLine("Costos Fijos Totales (C.F.)           : ");
            cF = float.Parse(Console.ReadLine());

            PEQ Calculo1 = new PEQ(pV, cVU, cF);
            Calculo1.CalculoTotal();
            Console.WriteLine("\nEL MARGEN DE CONTRIBUCIÓN UNITARIO (M.C.U.) ES                  : " + Calculo1.MCU);
            PEQ Calculo2 = new PEQ(pV, cVU, cF);
            Calculo2.CalculoTotal();
            Console.WriteLine("EL PUNTO DE EQUILIBRIO (P.E.Q.) PARA UNIDADES ES                : " + Calculo2.PEQU);
            PEQ Calculo3 = new PEQ(pV, cVU, cF);
            Calculo3.CalculoTotal();
            Console.WriteLine("EL PUNTO DE EQUILIBRIO (P.E.Q.) PARA VALORES MONETARIOS ES      : " + Calculo3.PEQM);
        }
    }
}