﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto3
{
    internal class Proceso : Calculo
    {
        public float PP { get; set; }
        public float TR { get; set; }
        public float CP1 { get; set; }
        public float CMX { get; set; }
        public float CMN { get; set; }
        public float EMX { get; set; }
        public float EMN { get; set; }
        public float CP2 { get; set; }
        public float E { get; set; }
        public Proceso(float tR, float cP1, float cMX, float cMN, float e)
        {
            PP = 0;
            EMN = 0;
            EMX = 0;
            CP2 = 0;
            TR = tR;
            CP1 = cP1;
            CMX = cMX;
            CMN = cMN;
            E = e;
        }

        public override void CalculoTotal()
        {
            EMN = CMN * TR;
            PP = (CP1 * TR) + EMN;
            EMX = (CMX * TR) + EMN;
            CP2 = EMX - E;
        }


    }
}
