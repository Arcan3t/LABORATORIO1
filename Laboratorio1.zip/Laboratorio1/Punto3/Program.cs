﻿using System;

namespace Punto3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            float tR = 0; 
            float cP1 = 0;
            float cMX = 0;
            float cMN = 0;
            float e = 0;

            Console.WriteLine("HOLA MUNDO");
            Console.WriteLine("BIENVENIDOS A MI TRABAJO - LABORATORIO - PUNTO 3");

            Console.WriteLine("\n*** CALCULO DE LOS NIVELES OPTIMOS DEL INVENTARIO ***");
            Console.WriteLine("Consumo Minimo Diario                             : ");
            cMN = float.Parse(Console.ReadLine());
            Console.WriteLine("Consumo Máximo Diario                             : ");
            cMX = float.Parse(Console.ReadLine());
            Console.WriteLine("Tiempo de Reposición de Inventario (En Días)      : ");
            tR = float.Parse(Console.ReadLine());
            Console.WriteLine("Consumo Medio Diario                              : ");
            cP1 = float.Parse(Console.ReadLine());
            Console.WriteLine("Existencia Actual                                 : ");
            e = float.Parse(Console.ReadLine());

            Proceso Calculo1 = new Proceso(tR, cP1, cMX, cMN, e);
            Calculo1.CalculoTotal();
            Console.WriteLine("\nLA EXISTENCIA MINIMA ES      : " + Calculo1.EMN);
            Proceso Calculo2 = new Proceso(tR, cP1, cMX, cMN, e);
            Calculo2.CalculoTotal();
            Console.WriteLine("EL PUNTO DE PEDIDO ES        : " + Calculo2.PP);
            Proceso Calculo3 = new Proceso(tR, cP1, cMX, cMN, e);
            Calculo3.CalculoTotal();
            Console.WriteLine("LA EXISTENCIA MAXIMA ES      : " + Calculo3.EMX);
            Proceso Calculo4 = new Proceso(tR, cP1, cMX, cMN, e);
            Calculo4.CalculoTotal();
            Console.WriteLine("LA CANTIDAD DE PEDIDO ES     : " + Calculo4.CP2);
        }
    }
}