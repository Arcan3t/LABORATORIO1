﻿using System.Diagnostics.CodeAnalysis;

namespace Punto4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n1 = 0;
            int n2 = 0;
            int n3 = 0;
            int n4 = 0;
            int n5 = 0;            
            int suma = 0;
            
            Console.WriteLine("HOLA MUNDO");
            Console.WriteLine("BIENVENIDOS A MI TRABAJO - LABORATORIO - PUNTO 4");
            
            Console.WriteLine("\n*** CALCULO DE LA MEDIA ***");
            Console.WriteLine("ESCRIBA 5 NÚMEROS");
            Console.WriteLine("Primero :");
            n1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Segundo :");
            n2 = int.Parse(Console.ReadLine());
            Console.WriteLine("Tercero :");
            n3 = int.Parse(Console.ReadLine());
            Console.WriteLine("Cuarto :");
            n4 = int.Parse(Console.ReadLine());
            Console.WriteLine("Quinto :");
            n5 = int.Parse(Console.ReadLine());

            int[] valores = { n1, n2, n3, n4, n5 };
            for (int i = 0; i < valores.Length; i++)
            {
                suma += valores[i];                
            }

            float media = (float)suma / valores.Length;
            float varianza = (float)(Math.Pow(n1 - media, 2) + Math.Pow(n2 - media, 2) + Math.Pow(n3 - media, 2) + Math.Pow(n4 - media, 2) + Math.Pow(n5 - media, 2)) / valores.Length;
            float de = (float)Math.Sqrt(varianza);
            Console.WriteLine("\nLA MEDIA ES                  : " + media);
            Console.WriteLine("LA VARIANZA ES               : " + varianza + "^2");
            Console.WriteLine("LA DESVIACIÓN ESTÁNDAR ES    : " + de);
        }
    }
}