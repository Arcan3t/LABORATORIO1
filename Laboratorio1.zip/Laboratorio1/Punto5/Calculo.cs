﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto5
{
    internal abstract class Calculo
    {
        public float Area { get; set; }
        public float Volumen { get; set; }
        abstract public void Calculos();
    }
}
