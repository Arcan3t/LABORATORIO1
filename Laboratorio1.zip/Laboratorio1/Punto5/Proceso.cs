﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto5
{
    internal class Proceso : Calculo
    {
        public float Radio { get; set; }
        public float Altura { get; set; }
        public Proceso(float radio, float altura)
        {
            Radio = radio;
            Altura = altura;
            Area = 0;
            Volumen = 0;
        }

        public override void Calculos()
        {
            Volumen = (float)(Math.PI * Math.Pow(Radio, 2) * Altura);
            Area = (float)(2 * Math.PI * Radio * Altura) + (float)(2 * Math.PI * Math.Pow(Radio, 2));
        }



    }
}
