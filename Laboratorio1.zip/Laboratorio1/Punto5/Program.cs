﻿namespace Punto5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            float radio = 0;
            float altura = 0;

            Console.WriteLine("HOLA MUNDO");
            Console.WriteLine("BIENVENIDOS A MI TRABAJO - LABORATORIO - PUNTO 5");

            Console.WriteLine("\n*** CALCULO DEL CILINDRO ***");
            Console.WriteLine("Ingrese el Radio  : ");
            radio = float.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese la Altura : ");
            altura = float.Parse(Console.ReadLine());
            
            Proceso CalculoA = new Proceso(radio, altura);
            CalculoA.Calculos();
            Console.WriteLine("\nEL AREA DEL CILINDRO ES  : " + CalculoA.Area);
            Proceso CalculoV = new Proceso(radio, altura);
            CalculoV.Calculos();
            Console.WriteLine("EL VOLUMEN DEL CILINDRO ES : " + CalculoV.Volumen);
        }
    }
}